<?php
 session_start(); 
 ?>
<html>
	<head>
		<title>Test</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	</head>
	<body>
		
		<form name="form" action="addsubcategory_submit.php" method="POST" enctype="multipart/form-data">
			Category :
			<select name="category" >
			<?php
				include "db.php";
				$res=$mysqli->query("SELECT * FROM category ");
				while($row=$res->fetch_assoc()){
				?>
				
				<option value="<?php echo $row['id']; ?>" ><?php echo $row['category']; ?></option>
				<?php  } ?>
				</select>
				SubCategory Name:<input type="text" name="subcategory"  id="name" >
				<input type="submit" name="submit"  value="Submit"  id="formsubmit">

		</form>
							
	</body>
</html>