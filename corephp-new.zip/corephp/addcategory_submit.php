<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $name=$_POST["name"];
	
	$mysqli->query("INSERT into category (id, category ) VALUES (NULL, '$name')");

}
header("location:products.php");
?>
