<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $category=$_POST["category"];
    $subcategory=$_POST["subcategory"];
    $name=$_POST["name"];
    $description=$_POST["description"];
    $price=$_POST["price"];
	
	if($_FILES['image']['name'] !=""){
		$file_name = $_FILES['image']['name'];
		move_uploaded_file($_FILES['image']['tmp_name'],"uploads/".$file_name);
	}
	else{
		$file_name ="";
	}
	$mysqli->query("INSERT into product (id, category, subcategory, name, description, price,image  ) VALUES (NULL, '$category', '$subcategory', '$name', '$description', '$price', '$file_name')");

}
header("location:products.php");
?>
