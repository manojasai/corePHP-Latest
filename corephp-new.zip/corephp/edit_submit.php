<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $name=$_POST["name"];
    $description=$_POST["description"];
    $price=$_POST["price"];
    $id=$_POST["id"];
	
	if($_FILES['image']['name'] !=""){
		$file_name = $_FILES['image']['name'];
		move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$file_name);
		$mysqli->query("UPDATE product SET name='$name',description='$description',price='$price',image='$file_name' where id='$id'");
	}
	else{
		$mysqli->query("UPDATE product SET name='$name',description='$description',price='$price' where id='$id'");
	}

}
header("location:products.php");
?>
