<?php
session_start();
include "db.php";
if(!empty($_POST["submit"])){
    $category=$_POST["category"];
    $subcategory=$_POST["subcategory"];
	
	$mysqli->query("INSERT into subcategory (id, category, subcategory ) VALUES (NULL, '$category', '$subcategory')");

}
header("location:products.php");
?>
